import "./Profile.css";

function Profile(){
    return (
        <div className="layout">
      {/* <img src="https://www.humanesociety.org/sites/default/files/2021-02/mink-186995.jpg"/> */}
      <img src="assets/mink.jpg" alt="profile"/>
            <h1 className="name">Mink Lim</h1>
            <hr></hr>
        </div>
    )
}
export default Profile;